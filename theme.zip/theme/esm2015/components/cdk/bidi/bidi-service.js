import { Injectable } from '@angular/core';
import { Directionality } from '@angular/cdk/bidi';
export class NbDirectionality extends Directionality {
}
NbDirectionality.decorators = [
    { type: Injectable }
];
//# sourceMappingURL=bidi-service.js.map