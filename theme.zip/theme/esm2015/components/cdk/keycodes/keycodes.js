export * from '@angular/cdk/keycodes';
//# sourceMappingURL=keycodes.js.map