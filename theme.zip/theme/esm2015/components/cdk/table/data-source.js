import { DataSource } from '@angular/cdk/table';
export class NbDataSource extends DataSource {
}
//# sourceMappingURL=data-source.js.map