export {};
//# sourceMappingURL=component-shape.js.map