export {};
//# sourceMappingURL=component-size.js.map