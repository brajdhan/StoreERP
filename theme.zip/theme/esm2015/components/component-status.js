export {};
//# sourceMappingURL=component-status.js.map