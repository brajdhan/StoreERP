import { Directionality } from '@angular/cdk/bidi';
import * as ɵngcc0 from '@angular/core';
export declare class NbDirectionality extends Directionality {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbDirectionality, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDeclaration<NbDirectionality>;
}

//# sourceMappingURL=bidi-service.d.ts.map