import { BidiModule } from '@angular/cdk/bidi';
import * as ɵngcc0 from '@angular/core';
export declare class NbBidiModule extends BidiModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbBidiModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<NbBidiModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<NbBidiModule>;
}

//# sourceMappingURL=bidi.module.d.ts.map