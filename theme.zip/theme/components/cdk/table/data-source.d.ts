import { DataSource } from '@angular/cdk/table';
export declare abstract class NbDataSource<T> extends DataSource<T> {
}
