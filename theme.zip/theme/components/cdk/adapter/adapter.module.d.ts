import { ModuleWithProviders } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NbCdkAdapterModule {
    static forRoot(): ModuleWithProviders<NbCdkAdapterModule>;
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbCdkAdapterModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<NbCdkAdapterModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<NbCdkAdapterModule>;
}

//# sourceMappingURL=adapter.module.d.ts.map