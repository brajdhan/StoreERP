import { Platform } from '@angular/cdk/platform';
import * as ɵngcc0 from '@angular/core';
export declare class NbPlatform extends Platform {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbPlatform, never>;
}

//# sourceMappingURL=platform-service.d.ts.map