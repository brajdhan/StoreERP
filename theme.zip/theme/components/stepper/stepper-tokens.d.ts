import { InjectionToken } from '@angular/core';
export declare const NB_STEPPER: InjectionToken<unknown>;
