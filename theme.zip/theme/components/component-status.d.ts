export declare type NbComponentStatus = 'basic' | 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'control';
export declare type NbComponentOrCustomStatus = NbComponentStatus | string;
