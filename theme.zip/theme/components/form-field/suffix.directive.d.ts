import * as ɵngcc0 from '@angular/core';
export declare class NbSuffixDirective {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbSuffixDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDeclaration<NbSuffixDirective, "[nbSuffix]", never, {}, {}, never>;
}

//# sourceMappingURL=suffix.directive.d.ts.map