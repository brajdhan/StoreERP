import * as ɵngcc0 from '@angular/core';
export declare class NbPrefixDirective {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbPrefixDirective, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDeclaration<NbPrefixDirective, "[nbPrefix]", never, {}, {}, never>;
}

//# sourceMappingURL=prefix.directive.d.ts.map