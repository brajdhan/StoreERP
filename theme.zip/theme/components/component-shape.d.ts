export declare type NbComponentShape = 'rectangle' | 'semi-round' | 'round';
