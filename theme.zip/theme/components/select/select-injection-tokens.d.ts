import { InjectionToken } from '@angular/core';
export declare const NB_SELECT_INJECTION_TOKEN: InjectionToken<unknown>;
