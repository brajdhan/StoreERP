import { InjectionToken } from '@angular/core';
export declare const NB_TREE_GRID: InjectionToken<unknown>;
