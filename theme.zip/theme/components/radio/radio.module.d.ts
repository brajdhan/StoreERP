import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './radio.component';
import * as ɵngcc2 from './radio-group.component';
export declare class NbRadioModule {
    static ɵfac: ɵngcc0.ɵɵFactoryDeclaration<NbRadioModule, never>;
    static ɵmod: ɵngcc0.ɵɵNgModuleDeclaration<NbRadioModule, [typeof ɵngcc1.NbRadioComponent, typeof ɵngcc2.NbRadioGroupComponent], never, [typeof ɵngcc1.NbRadioComponent, typeof ɵngcc2.NbRadioGroupComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDeclaration<NbRadioModule>;
}

//# sourceMappingURL=radio.module.d.ts.map