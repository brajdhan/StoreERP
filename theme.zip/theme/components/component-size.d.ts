export declare type NbComponentSize = 'tiny' | 'small' | 'medium' | 'large' | 'giant';
